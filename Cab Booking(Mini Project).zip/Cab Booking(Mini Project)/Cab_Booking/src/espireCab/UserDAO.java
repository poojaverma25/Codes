package espireCab;
import java.sql.SQLException;

public interface UserDAO {

	void addUser() throws SQLException;
}
