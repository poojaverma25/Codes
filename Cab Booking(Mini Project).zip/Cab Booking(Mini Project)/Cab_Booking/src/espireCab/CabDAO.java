package espireCab;
import java.sql.SQLException;

public interface CabDAO {

	public Cab viewAllCabs() throws SQLException;
}
