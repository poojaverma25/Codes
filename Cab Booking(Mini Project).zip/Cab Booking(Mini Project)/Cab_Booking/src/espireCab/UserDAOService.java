package espireCab;
import java.sql.SQLException;

public interface UserDAOService {

	void addnewUser() throws SQLException;
}
