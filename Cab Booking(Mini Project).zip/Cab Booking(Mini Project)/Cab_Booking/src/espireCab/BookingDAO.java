package espireCab;
import java.sql.SQLException;

public interface BookingDAO {

	public Booking viewAllBookings() throws SQLException;

}
