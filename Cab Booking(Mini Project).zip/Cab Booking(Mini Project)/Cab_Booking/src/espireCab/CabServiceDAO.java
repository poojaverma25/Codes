package espireCab;
import java.sql.SQLException;

public interface CabServiceDAO {

	void showAllCabs() throws SQLException;
}
